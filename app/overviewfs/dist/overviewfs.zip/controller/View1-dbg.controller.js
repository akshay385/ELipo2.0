sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
    function (Controller) {
        "use strict";

        var data = [];

        return Controller.extend("overviewfs.controller.View1", {
            onTilePress: function (oEvent) {
                debugger
            }




        });
    });
