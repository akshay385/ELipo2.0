sap.ui.define(
    ["sap/ovp/app/Component"],
    function (Component) {
        "use strict";

        return Component.extend("overviewelipo.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);