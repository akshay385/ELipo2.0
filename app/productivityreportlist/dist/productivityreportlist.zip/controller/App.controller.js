sap.ui.define(["sap/ui/core/mvc/Controller"],function(t){"use strict";return t.extend("productivityreportlist.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map