sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("aging.controller.aging",{onInit:function(){}})});
//# sourceMappingURL=aging.controller.js.map