sap.ui.define(["sap/ovp/app/Component"],function(e){"use strict";return e.extend("overviewelipo.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map